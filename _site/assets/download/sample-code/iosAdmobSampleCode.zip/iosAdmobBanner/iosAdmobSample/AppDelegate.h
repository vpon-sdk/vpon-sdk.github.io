//
//  AppDelegate.h
//  iosAdmobSample
//
//  Created by FinnVpon on 2015/8/18.
//  Copyright (c) 2015年 FinnVpon. All rights reserved.
//


#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>{
    UIWindow *window;
    ViewController *viewController;
}

@end