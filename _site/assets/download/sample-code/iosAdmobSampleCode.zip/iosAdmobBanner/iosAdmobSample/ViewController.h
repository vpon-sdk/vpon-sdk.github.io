//
//  ViewController.h
//  iosAdmobSample
//
//  Created by FinnVpon on 2015/8/18.
//  Copyright (c) 2015年 FinnVpon. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VpadnBanner.h"
#import "VpadnInterstitial.h"
#import <UIKit/UIKit.h>
@import GoogleMobileAds;
//#import "GADBannerViewDelegate.h"

@class GADBannerView, GADRequest;

@interface ViewController : UIViewController<GADBannerViewDelegate> {
    GADBannerView *adBanner_;
}

@property (nonatomic, retain) GADBannerView *adBanner;

- (GADRequest *)createRequest;

@end

