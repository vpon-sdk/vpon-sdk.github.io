//
//  ViewController.h
//  iosAdmobIS
//
//  Created by FinnVpon on 2015/8/19.
//  Copyright (c) 2015年 FinnVpon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "VpadnInterstitial.h"
@import GoogleMobileAds;

@interface ViewController : UIViewController<GADCustomEventBanner,GADCustomEventInterstitial,GADBannerViewDelegate,GADInterstitialDelegate>
{
    GADBannerView *bannerView;
    GADInterstitial *interstitialView;
    UIButton *btnClick;
}

-(void)buttonPressed;


@end