//
//  ViewController.m
//  iosAdmobIS
//
//  Created by FinnVpon on 2015/8/19.
//  Copyright (c) 2015年 FinnVpon. All rights reserved.
//

#import "ViewController.h"
@import GoogleMobileAds;

#define My_Interstitial_Unit_ID @"";

@implementation ViewController

-(void)viewDidLoad
{
    [super viewDidLoad];
    
    btnClick = [[UIButton alloc]init];
    CGRect screenRect = [[UIScreen mainScreen]bounds];
    CGFloat screenWidth = screenRect.size.width;
    btnClick.frame = CGRectMake(0,250, screenWidth, 50);
    
    //see the button's title
    [btnClick setTitle:@"Click here can show interstitial" forState:UIControlStateNormal];
    btnClick.backgroundColor = [UIColor redColor];
    btnClick.hidden = NO;
    
    //listen for clicks
    [btnClick addTarget:self action:@selector(buttonPressed) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnClick];
    
    //get interstitial Ad
    interstitialView = [[GADInterstitial alloc]init];
    interstitialView.adUnitID = My_Interstitial_Unit_ID;
    interstitialView.delegate = self;
    [interstitialView loadRequest:[GADRequest request]];
}

-(void)buttonPressed
{
    [interstitialView presentFromRootViewController:self];
    btnClick.hidden = YES;
}

// Sent when an interstitial ad request completed successfully. The interstitial
// is ready to be presented at an appropriate time in your app.
- (void)interstitialDidReceiveAd:(GADInterstitial *)ad {
    NSLog(@"Received interstitial ad successfully");
    btnClick.hidden = NO;
}
// Sent when an interstitial ad request completed without an interstitial to
// show.
- (void)interstitial:(GADInterstitial *)ad
didFailToReceiveAdWithError:(GADRequestError *)error {
    NSLog(@"Failed to receive interstitail with error: %@", [error localizedFailureReason]);
    btnClick.hidden = YES;
}


- (void)dealloc {
    
    //    Don't release the bannerView and interstitialView if you are using ARC in your project
    //    [bannerView release];
    //    [interstitialView release];
    //    [super dealloc];
    
}


@end
