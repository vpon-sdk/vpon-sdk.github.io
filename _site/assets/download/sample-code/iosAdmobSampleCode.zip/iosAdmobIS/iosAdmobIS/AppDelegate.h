//
//  AppDelegate.h
//  iosAdmobIS
//
//  Created by FinnVpon on 2015/8/19.
//  Copyright (c) 2015年 FinnVpon. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>{
    UIButton* btnClick;
    UIWindow *window;
    ViewController *viewController;
}

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) ViewController *viewController;

@end

