//
//  NativeAdCell.h
//  iphone-vpon-sdk
//
//  Created by Mike Chou on 7/15/16.
//  Copyright © 2016 com.vpon. All rights reserved.
//

#import <UIKit/UIKit.h>
@class VpadnNativeAd;

@interface CustomCell : UITableViewCell

- (void)setNativeAd:(VpadnNativeAd *)nativeAd;

@end
