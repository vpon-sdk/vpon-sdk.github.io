//
//  AppDelegate.h
//  NativeSample
//
//  Created by Mike Chou on 10/24/16.
//  Copyright © 2016 Vpon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

