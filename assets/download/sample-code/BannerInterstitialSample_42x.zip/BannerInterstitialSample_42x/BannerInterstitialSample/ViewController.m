//
//  ViewController.m
//  BannerInterstitialSample
//
//  Created by Kelly on 2014/3/25.
//  Copyright (c) 2014年 Vpadn. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    BOOL bStatusBarHide = [UIApplication sharedApplication].statusBarHidden;
    float screenHeight = [[UIScreen mainScreen] bounds].size.height;
    if(!bStatusBarHide)
    screenHeight -= 20;
    CGPoint origin = CGPointMake(0.0,screenHeight - CGSizeFromVpadnAdSize(VpadnAdSizeBanner).height);
    //        CGPoint origin = CGPointMake(0.0,0.0);
    
    
    vpadnAd = [[VpadnBanner alloc] initWithAdSize:VpadnAdSizeBanner origin:origin];
    vpadnAd.strBannerId = @"";   // 填入您的BannerId
    vpadnAd.delegate = self;
    vpadnAd.platform = @"TW"; //
    [vpadnAd setAdAutoRefresh:YES];
    [vpadnAd setRootViewController:self];
    [self.view addSubview:[vpadnAd getVpadnAdView]];
    [vpadnAd startGetAd:[self getTestIdentifiers]];
    
    btnClick = [[UIButton alloc]init];
    CGRect screenRect = [[UIScreen mainScreen]bounds];
    CGFloat screenWidth = screenRect.size.width;
    btnClick.frame = CGRectMake(0,30, screenWidth, 50);
    
    //see the button's title
    [btnClick setTitle:@"Click here can show interstitial" forState:UIControlStateNormal];
    btnClick.hidden = YES;
    
    //listen for clicks
    [btnClick addTarget:self action:@selector(buttonPressed) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnClick];
    
    // get Interstitial Ad
    vpadnInterstitial = [[VpadnInterstitial alloc] init];
    vpadnInterstitial.strBannerId = @"";   // 填入您的Interstitial BannerId
    vpadnInterstitial.platform = @"TW";       // 台灣地區請填TW 大陸則填CN
    vpadnInterstitial.delegate = self;
    [vpadnInterstitial getInterstitial:[self getTestIdentifiers]];
}

-(void)buttonPressed{
    [vpadnInterstitial show];
}


// 請新增此function到您的程式內 如果為測試用 則在下方填入UUID
-(NSArray*)getTestIdentifiers
{
    return [NSArray arrayWithObjects:
            // add your test UUID
            nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark VpadnAdDelegate method 接一般Banner廣告就需要新增
- (void)onVpadnAdReceived:(UIView *)bannerView{
    NSLog(@"廣告抓取成功");
}

- (void)onVpadnAdFailed:(UIView *)bannerView didFailToReceiveAdWithError:(NSError *)error{
    NSLog(@"廣告抓取失敗");
}

- (void)onVpadnPresent:(UIView *)bannerView{
    NSLog(@"開啟vpadn廣告頁面 %@",bannerView);
}

- (void)onVpadnDismiss:(UIView *)bannerView{
    NSLog(@"關閉vpadn廣告頁面 %@",bannerView);
}

- (void)onVpadnLeaveApplication:(UIView *)bannerView{
    NSLog(@"離開publisher application");
}

#pragma mark VpadnInterstitial Delegate 有接Interstitial的廣告才需要新增
- (void)onVpadnInterstitialAdReceived:(UIView *)bannerView{
    NSLog(@"插屏廣告抓取成功");
    btnClick.hidden = NO;
}

- (void)onVpadnInterstitialAdFailed:(UIView *)bannerView{
    NSLog(@"插屏廣告抓取失敗");
}

- (void)onVpadnInterstitialAdDismiss:(UIView *)bannerView{
    NSLog(@"關閉插屏廣告頁面 %@",bannerView);
}

- (void)dealloc
{
    if(nil != vpadnInterstitial)
    {
        [vpadnInterstitial release];
        vpadnInterstitial = nil;
    }
    if(nil != vpadnAd)
    {
        [vpadnAd release];
        vpadnAd = nil;
    }
    [super dealloc];
}
@end

