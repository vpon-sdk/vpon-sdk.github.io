//
//  ViewController.h
//  BannerInterstitialSample
//
//  Created by Kelly on 2014/3/25.
//  Copyright (c) 2014年 Vpadn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VpadnBanner.h"
#import "VpadnInterstitial.h"

@interface ViewController : UIViewController<VpadnBannerDelegate, VpadnInterstitialDelegate>
{
    VpadnBanner*         vpadnAd;
    VpadnInterstitial*   vpadnInterstitial;
    UIButton* btnClick;
}

-(void)buttonPressed;

@end
