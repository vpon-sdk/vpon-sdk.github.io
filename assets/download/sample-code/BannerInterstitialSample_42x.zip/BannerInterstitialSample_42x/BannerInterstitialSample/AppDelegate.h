//
//  AppDelegate.h
//  BannerInterstitialSample
//
//  Created by Kelly on 2014/3/25.
//  Copyright (c) 2014年 Vpadn. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>{
    UIButton* btnClick;
}

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end

