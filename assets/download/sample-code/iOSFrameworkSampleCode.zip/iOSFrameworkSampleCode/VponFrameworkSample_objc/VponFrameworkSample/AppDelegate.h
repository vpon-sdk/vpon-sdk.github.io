//
//  AppDelegate.h
//  VponFrameworkSample
//
//  Created by Mike Chou on 10/12/15.
//  Copyright © 2015 Mike Chou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

