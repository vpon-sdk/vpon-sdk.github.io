//
//  AppDelegate.h
//  BannerInterstitialSample
//
//  Created by Mike Chou on 10/28/15.
//  Copyright © 2015 Vpon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

