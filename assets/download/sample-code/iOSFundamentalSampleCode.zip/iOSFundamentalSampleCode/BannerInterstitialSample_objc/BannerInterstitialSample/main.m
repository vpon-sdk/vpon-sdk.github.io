//
//  main.m
//  BannerInterstitialSample
//
//  Created by Mike Chou on 10/28/15.
//  Copyright © 2015 Vpon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
