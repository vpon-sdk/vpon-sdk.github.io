//
//  ViewController.h
//  BannerInterstitialSample
//
//  Created by Mike Chou on 10/28/15.
//  Copyright © 2015 Vpon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

