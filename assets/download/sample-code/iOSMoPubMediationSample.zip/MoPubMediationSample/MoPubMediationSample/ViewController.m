//
//  ViewController.m
//  BannerInterstitialSample
//
//  Created by Mike Chou on 10/28/15.
//  Copyright © 2015 Vpon. All rights reserved.
//

@import VpadnSDKAdKit;

#import "ViewController.h"

#import <MPAdView.h>
#import <MPInterstitialAdController.h>

#import "MPVponBannerCustomEvent.h"
#import "MPVponInterstitialCustomEvent.h"

@interface ViewController ()<MPAdViewDelegate, MPInterstitialAdControllerDelegate>

@property (weak, nonatomic) IBOutlet UILabel *versionLabel;
@property (weak, nonatomic) IBOutlet UIView *bannerView;
@property (weak, nonatomic) IBOutlet UIButton *showInterstitialBtn;

@property (nonatomic, strong) MPAdView *bannerAd;
@property (nonatomic, strong) MPInterstitialAdController *interstitialAd;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    // Show the sdk version on the screen.
    self.versionLabel.text = [NSString stringWithFormat:@"version: %@", [VpadnBanner getVersionVpadn]];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskLandscape;
}

#pragma mark - MPAdViewDelegate
- (UIViewController *)viewControllerForPresentingModalView {
    return self;
}

- (void)adViewDidLoadAd:(MPAdView *)view {
    NSLog(@"MoPub Banner 抓取成功");
}

- (void)adViewDidFailToLoadAd:(MPAdView *)view {
    NSLog(@"MoPub Banner 抓取失敗");
}

- (void)willPresentModalViewForAd:(MPAdView *)view {
    NSLog(@"MoPub Banner 將被展示");
}

- (void)didDismissModalViewForAd:(MPAdView *)view {
    NSLog(@"MoPub Banner 已被關閉");
}

- (void)willLeaveApplicationFromAd:(MPAdView *)view {
    NSLog(@"MoPub Banner 離開publisher application");
}

#pragma mark - MPInterstitialAdControllerDelegate
- (void)interstitialDidLoadAd:(MPInterstitialAdController *)interstitial {
    NSLog(@"MoPub Interstitial 抓取成功");
    if (interstitial == self.interstitialAd && interstitial.ready) {
        [_showInterstitialBtn setHidden:NO];
    }
}

- (void)interstitialDidFailToLoadAd:(MPInterstitialAdController *)interstitial {
    NSLog(@"MoPub Interstitial 抓取失敗");
}

- (void)interstitialDidAppear:(MPInterstitialAdController *)interstitial {
    NSLog(@"MoPub Interstitial 已展示");
}

- (void)interstitialDidDisappear:(MPInterstitialAdController *)interstitial {
    NSLog(@"MoPub Interstitial 已關閉");
}

#pragma mark - Custom Action

- (IBAction)showBannerAd:(id)sender {
    
    // create an CGPoint origin for the banner to show in the middle of the bannerView
    float screenWidth = [[UIScreen mainScreen] bounds].size.width;
    CGPoint origin = CGPointMake((screenWidth - VpadnAdSizeBanner.size.width)/2.0f , 0);

    // Set up MoPub Banner
    self.bannerAd = [[MPAdView alloc] initWithAdUnitId:@"<YOUR_ADUNIT_ID_HERE>" size:MOPUB_BANNER_SIZE];
    self.bannerAd.frame = CGRectMake(origin.x, origin.y, MOPUB_BANNER_SIZE.width, MOPUB_BANNER_SIZE.height);
    self.bannerAd.delegate = self;
    [self.bannerView addSubview:self.bannerAd];
    [self.bannerAd loadAd];
}

- (IBAction)getInterstitialAd:(id)sender {
    
    // Set up MoPub Interstitial
    self.interstitialAd = [MPInterstitialAdController interstitialAdControllerForAdUnitId:@"<YOUR_ADUNIT_ID_HERE>"];
    self.interstitialAd.delegate = self;
    [self.interstitialAd loadAd];
    
}

- (IBAction)showInterstitialAd:(id)sender {
    
    // Show interstitialAd
    if (self.interstitialAd.ready) {
        [self.interstitialAd showFromViewController:self];
    }
    [_showInterstitialBtn setHidden:YES];
}


@end
