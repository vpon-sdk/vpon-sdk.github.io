//
//  ViewController.m
//  NativeSample
//
//  Created by Mike Chou on 10/24/16.
//  Copyright © 2016 Vpon. All rights reserved.
//

#import "ViewController.h"
#import "MPNativeAdDelegate.h"
#import "MPVponNativeAdView.h"
#import "MPNativeAd.h"
#import "MPNativeAdRequest.h"
#import "MPNativeAdConstants.h"
#import "MPNativeAdRequestTargeting.h"
#import "MPStaticNativeAdRendererSettings.h"
#import "MPNativeAdRendererConfiguration.h"
#import "MPStaticNativeAdRenderer.h"
#import "MPVponNativeCustomEvent.h"

@interface ViewController ()<MPNativeAdDelegate>

@property (weak, nonatomic) IBOutlet UILabel *statusLabel;
@property (weak, nonatomic) IBOutlet UIView *adView;

@property (strong, nonatomic) MPNativeAd *nativeAd;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (IBAction)loadNativeAd:(id)sender {
    
    MPStaticNativeAdRendererSettings *settings = [[MPStaticNativeAdRendererSettings alloc] init];
    settings.renderingViewClass = [MPVponNativeAdView class];

    MPNativeAdRendererConfiguration *config = [MPStaticNativeAdRenderer rendererConfigurationWithRendererSettings:settings];
    config.supportedCustomEvents = @[@"MPVponNativeCustomEvent"];
    
    MPNativeAdRequest *adRequest = [MPNativeAdRequest requestWithAdUnitIdentifier:@"please insert MoPub ID" rendererConfigurations:@[config]];
    
    MPNativeAdRequestTargeting *targeting = [MPNativeAdRequestTargeting targeting];
    targeting.desiredAssets = [NSSet setWithObjects:kAdTitleKey, kAdTextKey, kAdCTATextKey, kAdIconImageKey, kAdMainImageKey, kAdStarRatingKey, nil];
    adRequest.targeting = targeting;
    
    __block typeof(self) safeSelf = self;
    [adRequest startWithCompletionHandler:^(MPNativeAdRequest *request, MPNativeAd *response, NSError *error) {
        if (error) {
            NSLog(@"%@",error);
        } else {
            
            safeSelf.nativeAd = response;
            safeSelf.nativeAd.delegate = self;
            UIView *nativeAdView = [response retrieveAdViewWithError:nil];
            nativeAdView.frame = self.adView.bounds;
            [self.adView addSubview:nativeAdView];
        }
    }];
}

#pragma mark MPNativeAdDelegate
-(UIViewController *)viewControllerForPresentingModalView {
    return self;
}

- (void)willPresentModalForNativeAd:(MPNativeAd *)nativeAd {
    NSLog(@"willPresentModalForNativeAd");
}

- (void)didDismissModalForNativeAd:(MPNativeAd *)nativeAd {
    NSLog(@"didDismissModalForNativeAd");
}

- (void)willLeaveApplicationFromNativeAd:(MPNativeAd *)nativeAd {
    NSLog(@"willLeaveApplicationFromNativeAd");
}

@end
