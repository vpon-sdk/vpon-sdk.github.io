//
//  MPVponNativeCustomEvent.h
//  Vpon
//
//  Copyright (c) 2016 Vpon. All rights reserved.
//

#if __has_include(<MoPub/MoPub.h>)
    #import <MoPub/MoPub.h>
#else
    #import "MPNativeCustomEvent.h"
#endif

@interface MPVponNativeCustomEvent : MPNativeCustomEvent

@end
