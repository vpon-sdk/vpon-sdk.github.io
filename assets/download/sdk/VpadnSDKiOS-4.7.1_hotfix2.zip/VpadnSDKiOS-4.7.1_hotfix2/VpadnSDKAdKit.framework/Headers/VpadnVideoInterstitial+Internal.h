//
//  VpadnVideoInterstitial+Internal.h
//  iphone-vpon-sdk
//
//  Created by Mike Chou on 5/9/16.
//  Copyright © 2016 com.vpon. All rights reserved.
//

@interface VpadnVideoInterstitial (Internal)

#pragma Fake UUID
- (void)setUseFakeUUID:(BOOL)bUseFakeUUID;
- (void)setFakeUUID:(NSString*)strTargetFakeUUID;

@end